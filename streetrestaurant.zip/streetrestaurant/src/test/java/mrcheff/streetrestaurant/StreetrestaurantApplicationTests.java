package mrcheff.streetrestaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreetrestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
