package mrcheff.streetrestaurant.controller;

import mrcheff.streetrestaurant.model.Ingrediente;
import mrcheff.streetrestaurant.model.Pedido;
import mrcheff.streetrestaurant.model.RolEmpleado;
import mrcheff.streetrestaurant.repository.IngredienteRepository;
import mrcheff.streetrestaurant.repository.PlatoRepository;
import mrcheff.streetrestaurant.service.IngredienteService;
import mrcheff.streetrestaurant.service.PedidoService;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/trabajos")
public class TrabajosController {

    private final IngredienteService ingredienteService;
    private final IngredienteRepository ingredienteRepository;
    private final PlatoRepository platoRepository;
    private final PedidoService pedidoService;

    public TrabajosController(IngredienteRepository ingredienteRepository, IngredienteService ingredienteService,
            PlatoRepository platoRepository, PedidoService pedidoService) {

        this.ingredienteRepository = ingredienteRepository;
        this.ingredienteService = ingredienteService;
        this.platoRepository = platoRepository;
        this.pedidoService = pedidoService;

    }

    @GetMapping("/caja")
    public String mostrarCaja(@RequestParam(required = false) Integer mesa,
            @RequestParam(required = false) String buscar,
            HttpSession session, Model model) {

        RolEmpleado rol = (RolEmpleado) session.getAttribute("rolCaja");

        if (rol != RolEmpleado.CAJA) {
            return "redirect:/sesiones/caja-login";
        }

        model.addAttribute("platos", platoRepository.findAll());
        model.addAttribute("mesa", mesa);
        model.addAttribute("detalles", pedidoService.obtenerDetalles(mesa));
        model.addAttribute("total", pedidoService.obtenerTotal(mesa));
        model.addAttribute("platos", pedidoService.buscarPlatos(buscar));
        model.addAttribute("busqueda", buscar);

        return "trabajos/caja";

    }

    @PostMapping("/caja/agregar")
    public String agregarCarrito(@RequestParam("idPlato") Integer idPlato, @RequestParam("mesa") Integer mesa) {

        pedidoService.agregarPlato(idPlato, mesa);

        return "redirect:/trabajos/caja?mesa=" + mesa;
    }

    @PostMapping("/caja/enviar")
    public String enviarCarrito(@RequestParam("mesa") Integer mesa, HttpSession session) {

        RolEmpleado rol = (RolEmpleado) session.getAttribute("rolCaja");

        if (rol != RolEmpleado.CAJA) {
            return "redirect:/sesiones/caja-login";
        }

        pedidoService.enviarPedido(mesa);

        return "redirect:/trabajos/caja";
    }

    @PostMapping("/caja/eliminar")
    public String eliminarCarrito(@RequestParam("idDetalle") Integer idDetalle, @RequestParam("mesa") Integer mesa) {

        pedidoService.eliminarDetalle(idDetalle, mesa);

        return "redirect:/trabajos/caja?mesa=" + mesa;
    }

    @GetMapping("/cocina")
    public String mostrarCocina(HttpSession session, Model model) {

        RolEmpleado rol = (RolEmpleado) session.getAttribute("rolCocina");

        if (rol != RolEmpleado.COCINA) {
            return "redirect:/sesiones/cocina-login";
        }

        List<Pedido> pedidos = pedidoService.obtenerPedidosPendientes();
        List<Pedido> pedidosPreparacion = pedidoService.obtenerPreparacion();
        List<Pedido> pedidosTerminados = pedidoService.obtenerTerminado();

        model.addAttribute("pedidosPreparacion", pedidosPreparacion);
        model.addAttribute("detallesPreparacion", pedidoService.obtenerDetallesDePedidos(pedidosPreparacion));
        model.addAttribute("detallesPorPedido", pedidoService.obtenerDetallesDePedidos(pedidos));
        model.addAttribute("pedidosTerminados", pedidosTerminados);
        model.addAttribute("detallesTerminados", pedidoService.obtenerDetallesDePedidos(pedidosTerminados));
        model.addAttribute("pedidos", pedidoService.obtenerPedidosPendientes());
        model.addAttribute("tiempos", pedidoService.obtenerTiempos(pedidos));

        return "trabajos/cocina";
    }

    @PostMapping("/cocina/iniciar/{id}")
    public String iniciarPreparacion(@PathVariable Integer id) {

        pedidoService.pedidosEnProceso(id);

        return "redirect:/trabajos/cocina";
    }

    @PostMapping("/cocina/terminar/{id}")
    public String terminarPedido(@PathVariable Integer id) {

        pedidoService.terminarPedido(id);

        return "redirect:/trabajos/cocina";
    }

    @PostMapping("/cocina/entregar/{id}")
    public String entregarPedido(@PathVariable Integer id) {

        pedidoService.entregarPedido(id);

        return "redirect:/trabajos/cocina";
    }

    @GetMapping("/administracion")
    public String mostrarAdministracion(@RequestParam(required = false) String buscar, HttpSession session,
            Model model) {

        RolEmpleado rol = (RolEmpleado) session.getAttribute("rolAdministracion");

        if (rol != RolEmpleado.ADMINISTRACION) {
            return "redirect:/sesiones/admin-login";
        }

        model.addAttribute("ingredientes", ingredienteRepository.findAll());
        model.addAttribute("ingredientes", ingredienteService.buscarIngredientes(buscar));
        model.addAttribute("busqueda", buscar);

        return "trabajos/administracion";

    }

    @PostMapping("/guardar-inventario")
    public String guardarInventario(@RequestParam String nombreIngrediente, @RequestParam BigDecimal stockActual,
            @RequestParam BigDecimal stockMinimo, @RequestParam String unidadMedida) {

        Ingrediente ingrediente = new Ingrediente();

        ingrediente.setNombreIngrediente(nombreIngrediente);
        ingrediente.setStockActual(stockActual);
        ingrediente.setStockMinimo(stockMinimo);
        ingrediente.setUnidadMedida(unidadMedida);

        ingredienteService.guardarIngrediente(ingrediente);

        return "redirect:/trabajos/administracion";
    }

    @PostMapping("/eliminar-inventario")
    public String eliminarInventario(@RequestParam Integer idIngrediente, HttpSession session) {

        RolEmpleado rol = (RolEmpleado) session.getAttribute("rolAdministracion");

        if (rol != RolEmpleado.ADMINISTRACION) {
            return "redirect:/sesiones/admin-login";
        }

        ingredienteService.eliminarIngrediente(idIngrediente);

        return "redirect:/trabajos/administracion";
    }
}