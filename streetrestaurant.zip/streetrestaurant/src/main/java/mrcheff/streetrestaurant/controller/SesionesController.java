package mrcheff.streetrestaurant.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

import mrcheff.streetrestaurant.model.RolEmpleado;
import mrcheff.streetrestaurant.service.LoginService;

import org.springframework.ui.Model;

@RequestMapping("/sesiones")
@Controller
public class SesionesController {

    private final LoginService loginService;

    public SesionesController(LoginService loginService) {
        this.loginService = loginService;
    }

    @GetMapping("/caja-login")
    public String cajero() {
        return "sesiones/caja-login";
    }

    @GetMapping("/cocina-login")
    public String cocinero() {
        return "sesiones/cocina-login";
    }

    @GetMapping("/admin-login")
    public String admin() {
        return "sesiones/admin-login";
    }

    @PostMapping("/caja-login")
    public String ingresarCaja(@RequestParam("usuario") String usuario, @RequestParam("password") String password,
            HttpSession session, Model model) {

        if (!loginService.validarAcceso(usuario, password, RolEmpleado.CAJA)) {
            model.addAttribute("mensaje", "Credenciales incorrectas o acceso no autorizado.");
            return "sesiones/caja-login";
        }

        session.setAttribute("rolCaja", RolEmpleado.CAJA);

        return "redirect:/trabajos/caja";
    }

    @PostMapping("/cocina-login")
    public String ingresarCocina(@RequestParam("usuario") String usuario, @RequestParam("password") String password,
            HttpSession session, Model model) {

        if (!loginService.validarAcceso(usuario, password, RolEmpleado.COCINA)) {
            model.addAttribute("mensaje", "Credenciales incorrectas o acceso no autorizado.");
            return "sesiones/cocina-login";
        }

        session.setAttribute("rolCocina", RolEmpleado.COCINA);

        return "redirect:/trabajos/cocina";
    }

    @PostMapping("/admin-login")
    public String ingresarAdministracion(@RequestParam("usuario") String usuario, @RequestParam("password") String password,
            HttpSession session, Model model) {

        if (!loginService.validarAcceso(usuario, password, RolEmpleado.ADMINISTRACION)) {
            model.addAttribute("mensaje", "Credenciales incorrectas o acceso no autorizado.");
            return "sesiones/admin-login";
        }

        session.setAttribute("rolAdministracion", RolEmpleado.ADMINISTRACION);

        return "redirect:/trabajos/administracion";
    }
}
