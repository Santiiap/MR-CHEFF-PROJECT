package mrcheff.streetrestaurant.controller;

import mrcheff.streetrestaurant.repository.PlatoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller 
public class LocalController {

     private final PlatoRepository platoRepository;

    LocalController(PlatoRepository platoRepository) {
        this.platoRepository = platoRepository;
    }

     @GetMapping("/inicio")
    public String inicio() {
        return "vista/inicio";
    }

    @GetMapping("/menu")
    public String menu(Model model) {

        model.addAttribute("platos", platoRepository.findAll());
        return "vista/menu";
    }

    @GetMapping("/empleados")
    public String login() {
        return "vista/empleados";
    }
}



