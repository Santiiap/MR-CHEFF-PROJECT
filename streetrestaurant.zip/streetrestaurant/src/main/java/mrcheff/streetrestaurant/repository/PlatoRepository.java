package mrcheff.streetrestaurant.repository;

import mrcheff.streetrestaurant.model.Plato;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlatoRepository extends JpaRepository <Plato, Integer> {

    List<Plato> findByNombrePlatoContainingIgnoreCase(String nombrePlato);
    
}
