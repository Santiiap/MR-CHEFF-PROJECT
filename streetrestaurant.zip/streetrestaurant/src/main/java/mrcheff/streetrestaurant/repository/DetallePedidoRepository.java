package mrcheff.streetrestaurant.repository;

import mrcheff.streetrestaurant.model.DetallePedido;
import mrcheff.streetrestaurant.model.Pedido;
import mrcheff.streetrestaurant.model.Plato;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DetallePedidoRepository extends JpaRepository <DetallePedido, Integer> {
    Optional<DetallePedido> findByPedidoAndPlato(Pedido pedido, Plato plato);

    List<DetallePedido> findByPedido(Pedido pedido);
}
