package mrcheff.streetrestaurant.repository;

import mrcheff.streetrestaurant.model.Ingrediente;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IngredienteRepository extends JpaRepository <Ingrediente, Integer> {

    List<Ingrediente> findByNombreIngredienteContainingIgnoreCase(String nombreIngrediente);

} 
