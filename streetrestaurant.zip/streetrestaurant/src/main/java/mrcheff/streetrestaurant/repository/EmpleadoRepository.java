package mrcheff.streetrestaurant.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import mrcheff.streetrestaurant.model.Empleado;

public interface EmpleadoRepository extends JpaRepository<Empleado, Integer> {

    Optional<Empleado> findByUsuario (String usuario);
    
}
