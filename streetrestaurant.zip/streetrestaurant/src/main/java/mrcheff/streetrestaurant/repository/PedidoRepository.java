package mrcheff.streetrestaurant.repository;

import mrcheff.streetrestaurant.model.EstadoPedido;
import mrcheff.streetrestaurant.model.Pedido;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PedidoRepository extends JpaRepository <Pedido, Integer>{
    Optional<Pedido> findByNumeroMesaAndEstado(int numeroMesa, EstadoPedido estado);
    List<Pedido> findByEstado(EstadoPedido estado);
}
