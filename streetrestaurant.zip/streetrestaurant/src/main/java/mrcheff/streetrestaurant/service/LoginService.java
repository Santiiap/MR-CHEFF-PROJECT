package mrcheff.streetrestaurant.service;

import mrcheff.streetrestaurant.model.Empleado;
import mrcheff.streetrestaurant.model.RolEmpleado;
import mrcheff.streetrestaurant.repository.EmpleadoRepository;

import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class LoginService {

    private final EmpleadoRepository empleadoRepository;
    private final PasswordEncoder passwordEncoder;

    public LoginService(EmpleadoRepository empleadoRepository, PasswordEncoder passwordEncoder) {

        this.empleadoRepository = empleadoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public boolean validarAcceso(String usuario, String password_hash, RolEmpleado rolEsperado) {

        Empleado empleado = empleadoRepository.findByUsuario(usuario).orElse(null);

        if (empleado == null) {
            return false;
        }

        if (!passwordEncoder.matches(password_hash, empleado.getPasswordHash())) {
            return false;
        }

        return empleado.getRol() == rolEsperado;
    }
}
