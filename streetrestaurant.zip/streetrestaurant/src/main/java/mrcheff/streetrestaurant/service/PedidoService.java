package mrcheff.streetrestaurant.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import mrcheff.streetrestaurant.model.Pedido;
import mrcheff.streetrestaurant.model.Plato;
import mrcheff.streetrestaurant.model.DetallePedido;
import mrcheff.streetrestaurant.model.EstadoPedido;
import mrcheff.streetrestaurant.repository.DetallePedidoRepository;
import mrcheff.streetrestaurant.repository.PlatoRepository;
import mrcheff.streetrestaurant.repository.PedidoRepository;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;
    private final PlatoRepository platoRepository;
    private final DetallePedidoRepository detallePedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository, PlatoRepository platoRepository,
            DetallePedidoRepository detallePedidoRepository) {

        this.pedidoRepository = pedidoRepository;
        this.platoRepository = platoRepository;
        this.detallePedidoRepository = detallePedidoRepository;
    }

    public Pedido agregarPedido(Integer mesa) {

        if (mesa == null || mesa < 1 || mesa > 6) {
            throw new IllegalArgumentException("Mesa inválida");
        }

        Pedido pedido = pedidoRepository.findByNumeroMesaAndEstado(mesa, EstadoPedido.EN_CAJA).orElse(null);

        if (pedido == null) {
            pedido = new Pedido();
            pedido.setNumeroMesa(mesa);
            pedido.setEstado(EstadoPedido.EN_CAJA);
            pedido.setFechaHora(LocalDateTime.now());
            pedido = pedidoRepository.save(pedido);
        }
        return pedido;
    }

    public List<Plato> buscarPlatos(String buscar) {

        if (buscar == null || buscar.isBlank()) {
            return platoRepository.findAll();
        }
        return platoRepository.findByNombrePlatoContainingIgnoreCase(buscar);
    }

    public void agregarPlato(Integer idPlato, Integer mesa) {

        Pedido pedido = agregarPedido(mesa);

        Plato plato = platoRepository.findById(idPlato)
                .orElseThrow(() -> new IllegalArgumentException("Plato no encontrado"));

        DetallePedido detalle = detallePedidoRepository.findByPedidoAndPlato(pedido, plato).orElse(null);

        if (detalle != null) {
            detalle.setCantidad(detalle.getCantidad() + 1);
            detallePedidoRepository.save(detalle);

        } else {
            detalle = new DetallePedido();
            detalle.setPedido(pedido);
            detalle.setPlato(plato);
            detalle.setCantidad(1);
            detalle.setPrecioUnitario(plato.getPrecio());
            detallePedidoRepository.save(detalle);
        }

    }

    public List<DetallePedido> obtenerDetalles(Integer mesa) {

        if (mesa == null) {
            return List.of();
        }

        Pedido pedido = pedidoRepository.findByNumeroMesaAndEstado(mesa, EstadoPedido.EN_CAJA).orElse(null);

        if (pedido == null) {
            return List.of();
        }

        return detallePedidoRepository.findByPedido(pedido);
    }

    public void eliminarDetalle(Integer idDetalle, Integer mesa) {

        if (mesa == null || mesa < 1 || mesa > 6) {
            throw new IllegalArgumentException("Mesa inválida");
        }

        DetallePedido detalle = detallePedidoRepository.findById(idDetalle)
                .orElseThrow(() -> new IllegalArgumentException("Detalle no encontrado"));

        if (detalle.getPedido().getNumeroMesa() != mesa) {
            throw new IllegalArgumentException("El producto no pertenece a esta mesa");
        }

        detallePedidoRepository.delete(detalle);
    }

    public void enviarPedido(Integer mesa) {

        if (mesa == null || mesa < 1 || mesa > 6) {
            throw new IllegalArgumentException("Mesa inválida");
        }

        Pedido pedido = pedidoRepository.findByNumeroMesaAndEstado(mesa, EstadoPedido.EN_CAJA).orElseThrow(() -> new IllegalArgumentException("No hay un pedido en Caja"));

        List<DetallePedido> detalles = detallePedidoRepository.findByPedido(pedido);

        if (detalles.isEmpty()) {
            throw new IllegalArgumentException("El pedido está vacío");
        }

        pedido.setEstado(EstadoPedido.PENDIENTE);

        pedidoRepository.save(pedido);
    }

    public BigDecimal obtenerTotal(Integer mesa) {

        BigDecimal total = BigDecimal.ZERO;

        List<DetallePedido> detalles = obtenerDetalles(mesa);

        for (DetallePedido detalle : detalles) {

            BigDecimal subtotal = detalle.getPrecioUnitario().multiply(BigDecimal.valueOf(detalle.getCantidad()));

            total = total.add(subtotal);
        }

        return total;
    }

    public List<Pedido> obtenerPedidosPendientes() {
        return pedidoRepository.findByEstado(EstadoPedido.PENDIENTE);
    }

    public Map<Integer, List<DetallePedido>> obtenerDetallesDePedidos(List<Pedido> pedidos) {

        Map<Integer, List<DetallePedido>> detallesPorPedido = new HashMap<>();

        for (Pedido pedido : pedidos) {
            detallesPorPedido.put(pedido.getIdPedido(), detallePedidoRepository.findByPedido(pedido));
        }
        return detallesPorPedido;
    }

    public long obtenerMinutosTranscurridos(Pedido pedido) {

        if (pedido.getFechaHora() == null) {
            return 0;
        }

        LocalDateTime ahora = LocalDateTime.now();

        return java.time.Duration.between(pedido.getFechaHora(), ahora).toSeconds();
    }

    public Map<Integer, Long> obtenerTiempos(List<Pedido> pedidos) {

        Map<Integer, Long> tiempos = new HashMap<>();

        for (Pedido pedido : pedidos) {
            tiempos.put(pedido.getIdPedido(), obtenerMinutosTranscurridos(pedido));
        }

        return tiempos;
    }

    public void pedidosEnProceso(Integer idPedido) {

        Pedido pedido = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        pedido.setEstado(EstadoPedido.EN_PREPARACION);

        pedidoRepository.save(pedido);
    }

    public List<Pedido> obtenerPreparacion() {
        return pedidoRepository.findByEstado(EstadoPedido.EN_PREPARACION);
    }

    public void terminarPedido(Integer idPedido) {

        Pedido pedido = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        pedido.setEstado(EstadoPedido.TERMINADO);

        pedidoRepository.save(pedido);
    }

    public List<Pedido> obtenerTerminado() {
        return pedidoRepository.findByEstado(EstadoPedido.TERMINADO);
    }

    public void entregarPedido(Integer idPedido) {

        Pedido pedido = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        pedido.setEstado(EstadoPedido.ENTREGADO);

        pedidoRepository.save(pedido);
    }

}
