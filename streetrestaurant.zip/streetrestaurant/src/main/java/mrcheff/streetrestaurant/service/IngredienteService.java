package mrcheff.streetrestaurant.service;

import mrcheff.streetrestaurant.model.Ingrediente;
import mrcheff.streetrestaurant.repository.IngredienteRepository;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class IngredienteService {

    private final IngredienteRepository ingredienteRepository;

    public IngredienteService(IngredienteRepository ingredienteRepository) {
        this.ingredienteRepository = ingredienteRepository;
    }

    public void guardarIngrediente(Ingrediente ingrediente) {
        ingredienteRepository.save(ingrediente);
    }

    public void eliminarIngrediente(Integer idIngrediente) {
        ingredienteRepository.deleteById(idIngrediente);
    }

    public List<Ingrediente> buscarIngredientes(String buscar) {

        if (buscar == null || buscar.isBlank()) {
            return ingredienteRepository.findAll();
        }

        return ingredienteRepository.findByNombreIngredienteContainingIgnoreCase(buscar);

    }

}
