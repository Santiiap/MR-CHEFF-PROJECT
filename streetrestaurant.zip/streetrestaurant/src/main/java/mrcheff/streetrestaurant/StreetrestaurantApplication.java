package mrcheff.streetrestaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreetrestaurantApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreetrestaurantApplication.class, args);
	}

}
