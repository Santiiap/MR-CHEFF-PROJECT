package mrcheff.streetrestaurant.model;

public enum RolEmpleado {

    CAJA,
    COCINA,
    ADMINISTRACION
    
} 