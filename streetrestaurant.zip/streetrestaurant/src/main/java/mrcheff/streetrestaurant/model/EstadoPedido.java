package mrcheff.streetrestaurant.model;

public enum EstadoPedido {

    EN_CAJA,
    PENDIENTE,
    EN_PREPARACION,
    TERMINADO,
    ENTREGADO
    
}
