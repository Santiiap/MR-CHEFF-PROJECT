package mrcheff.streetrestaurant.model;

import java.math.BigDecimal;

import jakarta.persistence.*;

@Entity
@Table(name = "platos")
public class Plato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_plato")
    private Integer idPlato;

    @Column(name = "nombre_plato", nullable = false)
    private String nombrePlato;

    @Column(name = "precio", nullable = false)
    private BigDecimal precio;

    @Column(name = "categoria", nullable = false)
    private String categoria;

    @Column(name = "imagen")
    private String imagen;

    public Plato(){
    }

    public Integer getIdPlato() {
    return idPlato;
    }

    public void setIdPlato(Integer idPlato) {
        this.idPlato = idPlato;
    }

    public String getNombrePlato() {
        return nombrePlato;
    }

    public void setNombrePlato(String nombrePlato) {
        this.nombrePlato = nombrePlato;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

}
